﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CEM.Model.Migrations
{
    /// <inheritdoc />
    public partial class createnewdatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
