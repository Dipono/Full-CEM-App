﻿select avg(Subject) as Subject, Subject
from Complains
group by Subject